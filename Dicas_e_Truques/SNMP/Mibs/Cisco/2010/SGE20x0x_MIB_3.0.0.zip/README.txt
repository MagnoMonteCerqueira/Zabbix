Cisco Small Business Managed Switch (SGE20x0/SGE20x0P) MIB Release Read Me

Please read the instruction below before you compile the MIBs.

Release Note
============
1. If you followed the compilation steps as instructed in the next section with MG-Soft application, and encountered compliation errors, the workaround to avoid these errors is as follows. 
	Step 1: On MG-Soft, go to View -> Preference -> MIB Modules and Aliases tab
	Step 2: Remove the following aliases.
		RFC1389-MIB with RIPv2-MIB
		RFC1286-MIB with BRIDGE-MIB
	

Compilation 
===========
1. These MIBs have been compiled with SilverCreek and MG-SOFT applications. 

2. With MG-Soft application, please do NOT use the batch compile option. Load MIBs files with "Scan For Source Files" option under Tools menu bar, and make sure Include subolder is checked. After scan, select "Compile All" from Modules menu bar.  
   
3. If you encounter any compilation errors, please make sure application has clean environment before loading these MIBs into it.
  -- For MG-Soft, when the Compiler application is launched, make sure there is NO registered/loaded MIB modules shown on Modules Window. To clean these registered/loaded MIB modules, please follow the instructions below. 

   Step 1: Mouse over Modules Window, and right click. Select "Select All".
   Step 2: Click "Delete" from Modules menu bar.
   Step 3: Follow the on-screen instructions. Confirm Deletion and make sure Database file and Registry information are checked. 
   Step 4: Load MIBs files and include the files under the sub-folder into MG-SOFT MIB Compiler, and then compile. NOTE: Do NOT use the Batch Compile option. 
  -- For SilverCreek, when the application is launched, make sure there is no Enterprise MIBs shown on the MIB Testing tab. To clean these Enterprise MIBs, please follow the instructions below. 
   Step 1: Launch the Load and Delete MIBs window from the MIB menu. 
   Step 2: Select all the MIBs to be deleted. 
   Step 3: Click "Delete Definition Files". 
   Step 4: Confirm Deletion. 
   Step 5: Load MIB files from the parent folder of the zip file. The files will be compiled automatically. 


Device SNMP Configuration
=========================
Refer to product administration guide for more information.


Copyright � 2010 Cisco Systems, Inc. All rights reserved.

   
