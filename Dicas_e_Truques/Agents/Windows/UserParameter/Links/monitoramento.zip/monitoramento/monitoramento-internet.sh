#!/bin/bash

case $1 in

start)
opc=1
;;

stop)
opc=2
;;

operadora)
opc=3
;;

ip)
opc=4
;;

servidor)
opc=5
;;

distancia)
opc=6
;;

latencia)
opc=7
;;

download)
opc=8
;;

upload)
opc=9
;;

esac

cat /tmp/teste.log | tail -1 | cut -d$'\t' -f$opc
