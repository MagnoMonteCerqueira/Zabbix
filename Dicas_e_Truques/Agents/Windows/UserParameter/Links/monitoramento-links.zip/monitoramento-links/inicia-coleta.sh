#!/bin/bash
/etc/zabbix/scripts/speadao.sh >> /tmp/teste.log


